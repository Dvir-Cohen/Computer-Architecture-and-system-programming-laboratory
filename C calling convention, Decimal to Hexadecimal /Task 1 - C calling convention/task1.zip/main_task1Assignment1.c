#include <stdio.h>

extern void assFunc(int x, int y);


int main(int argc, char** argv)
{
  int input[1024];
  int x,y;
  printf("Please enter one number:");
  fgets(input,32,stdin);
  sscanf(input,"%d",input);
  x= input[0];
  printf("Please enter another number:");
  fgets(input,32,stdin);
  sscanf(input,"%d",input);
  y= input[0];
  printf("first num: %d\n", x);
  printf("second num: %d\n", y);
  assFunc(x,y);
  return 0;
}

char c_checkValidity(int x, int y){
  if (x>=y)
    return '1';
  return '0';
}